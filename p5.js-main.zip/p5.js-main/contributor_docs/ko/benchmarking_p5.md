# p5.js 벤치마킹

벤치마킹은 https://github.com/limzykenneth/p5-benchmark의 자체 레파지토리로 이동했습니다. 최신 p5.js 버전의 벤치마크 결과는 https://limzykenneth.github.io/p5-benchmark/에서 확인 할 수 있습니다. 아직 진행중인 작업입니다.